# CRACK BY Xquerpant VIP — Server Analyzer

## Isi
- `server.js`: Node.js + Express API dan static server
- `public/`: UI iOS-inspired
- Analisis APK/ZIP di memori: mencari string yang terbaca, keyword autentikasi/trial, URL, dan file penting DEX/manifest
- Tidak mengeksekusi file, tidak mencoba key pada layanan eksternal, dan tidak memodifikasi APK

## Jalankan di VPS (Ubuntu/Debian)
Node.js 18+ dibutuhkan.

```bash
npm install
npm start
```

Lalu buka `http://IP-VPS:3000`.

## Rekomendasi sebelum dipublikasikan
1. Pakai domain + HTTPS (Nginx + Certbot).
2. Tambahkan autentikasi untuk membatasi siapa yang dapat mengunggah file.
3. Pasang firewall; buka port 80/443, batasi akses port 3000 ke localhost jika memakai Nginx.
4. Gunakan batas ukuran upload; default 50 MB.
5. Tambahkan rate limit dan pemindaian malware jika menerima upload publik.
6. File diproses di memori aplikasi dan tidak ditulis sebagai file permanen oleh endpoint ini. Log web server/VPS tetap dapat menyimpan metadata request.
7. Hasil bersifat indikatif, bukan bukti bahwa key valid atau login dapat dilewati.

Untuk penggunaan pribadi, jalankan di VPS sendiri dan jangan membagikan URL publik tanpa perlindungan.
