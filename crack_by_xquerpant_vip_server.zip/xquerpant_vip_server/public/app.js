const $=id=>document.getElementById(id);let file=null,reportText="";
function size(n){return n<1024?n+" B":n<1048576?(n/1024).toFixed(1)+" KB":(n/1048576).toFixed(2)+" MB"}
function choose(f){file=f;$("meta").textContent=f?`${f.name} · ${size(f.size)}`:"Belum ada file dipilih.";$("scan").disabled=!f}
$("file").addEventListener("change",e=>choose(e.target.files[0]));
["dragenter","dragover"].forEach(n=>$("drop").addEventListener(n,e=>{e.preventDefault();$("drop").classList.add("drag")}));
["dragleave","drop"].forEach(n=>$("drop").addEventListener(n,e=>{e.preventDefault();$("drop").classList.remove("drag")}));
$("drop").addEventListener("drop",e=>choose(e.dataTransfer.files[0]));
$("reset").onclick=()=>{file=null;$("file").value="";choose(null);$("results").innerHTML='<div class="empty">Pilih file lalu mulai analisis.</div>';$("count").textContent=$("urls").textContent=$("entries").textContent="—";$("status").textContent="Menunggu file";$("copy").disabled=true;reportText="";$("progress").classList.add("hidden")};
$("scan").onclick=async()=>{if(!file)return;$("scan").disabled=true;$("progress").classList.remove("hidden");$("bar").style.width="25%";$("phase").textContent="Mengirim file ke server…";$("status").textContent="Menganalisis";$("results").innerHTML="";
try{const fd=new FormData();fd.append("file",file);$("bar").style.width="55%";const r=await fetch("/api/analyze",{method:"POST",body:fd});const data=await r.json();if(!r.ok)throw new Error(data.error||"Analisis gagal");$("bar").style.width="100%";$("phase").textContent="Analisis selesai";$("status").textContent="Selesai";$("count").textContent=data.findings.length;$("urls").textContent=data.urls.length;$("entries").textContent=data.entryCount;
const add=(tag,title,detail)=>{const d=document.createElement("div");d.className="finding";const t=document.createElement("span");t.className="tag "+(tag==="INFO"?"info":"");t.textContent=tag;const b=document.createElement("b");b.textContent=title;const p=document.createElement("p");p.textContent=detail;d.append(t,b,p);$("results").append(d)};
add("INFO",data.filename,`${data.format} · ${size(data.size)}`);
if(data.parseWarning)add("REVIEW","Catatan parser",data.parseWarning);
if(data.importantFiles.length)add("INFO","File penting",data.importantFiles.join(", "));
for(const f of data.findings)add("REVIEW",`${f.title} · ${f.keyword}`,f.detail);
for(const u of data.urls.slice(0,15))add("INFO","URL terdeteksi",u);
if(!data.findings.length&&!data.urls.length)add("INFO","Tidak ada indikator umum","Bukan jaminan aman; beberapa string mungkin terkompresi atau diobfuscate.");
for(const n of data.notes)add("INFO","Catatan keamanan",n);
reportText=JSON.stringify(data,null,2);$("copy").disabled=false;
}catch(e){$("status").textContent="Gagal";addError(e.message)}finally{$("scan").disabled=!file}};
function addError(msg){const d=document.createElement("div");d.className="finding";const b=document.createElement("b");b.textContent="Analisis gagal";const p=document.createElement("p");p.textContent=msg;d.append(b,p);$("results").append(d)}
$("copy").onclick=async()=>{try{await navigator.clipboard.writeText(reportText);$("copy").textContent="Tersalin ✓";setTimeout(()=>$("copy").textContent="Salin laporan",1300)}catch(_){alert("Salin laporan tidak tersedia di browser ini.")}};