const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_UPLOAD = 50 * 1024 * 1024;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    const allowed = [".apk", ".dex", ".zip", ".txt", ".xml", ".json", ".smali", ".bin"];
    cb(null, allowed.includes(ext));
  }
});
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self';");
  next();
});
app.use(express.static(path.join(__dirname, "public")));

const patterns = [
  ["api_key", "Indikasi API key"], ["apikey", "Indikasi API key"],
  ["client_secret", "Indikasi client secret"], ["secret", "Kata secret"],
  ["token", "Kata token"], ["authorization", "Header authorization"],
  ["bearer", "Bearer token"], ["license", "Mekanisme lisensi"],
  ["licence", "Mekanisme lisensi"], ["trial", "Mekanisme trial"],
  ["premium", "Fitur premium"], ["verify", "Verifikasi"],
  ["validate", "Validasi"], ["auth", "Autentikasi"],
  ["login", "Alur login"], ["subscription", "Langganan"],
  ["expiry", "Masa berlaku"], ["expire", "Masa berlaku"]
];

function printableStrings(buffer) {
  const out = [];
  let current = "";
  for (const b of buffer) {
    if (b >= 32 && b <= 126) current += String.fromCharCode(b);
    else {
      if (current.length >= 4) out.push(current);
      current = "";
    }
  }
  if (current.length >= 4) out.push(current);
  return out;
}
function redact(s) {
  return s
    .replace(/([?&](?:key|token|api_key|secret|password)=)[^&\s"'<>]+/ig, "$1[REDACTED]")
    .replace(/\b[A-Za-z0-9_-]{32,}\b/g, "[LONG_VALUE_REDACTED]")
    .slice(0, 220);
}
function analyzeBuffer(buffer, filename) {
  const isZip = buffer.length > 4 && buffer[0] === 0x50 && buffer[1] === 0x4b;
  const strings = [];
  const entries = [];
  let parseWarning = null;
  if (isZip) {
    try {
      const zip = new AdmZip(buffer);
      const all = zip.getEntries();
      for (const entry of all.slice(0, 1500)) {
        if (entry.isDirectory) continue;
        entries.push(entry.entryName);
        const ext = path.extname(entry.entryName).toLowerCase();
        if ([".dex", ".xml", ".json", ".txt", ".smali", ".properties", ".js", ".html", ".yml", ".yaml"].includes(ext) ||
            ["AndroidManifest.xml", "resources.arsc"].includes(path.basename(entry.entryName))) {
          try {
            const data = entry.getData();
            strings.push(...printableStrings(data).slice(0, 20000));
          } catch (_) {}
        }
      }
    } catch (_) {
      parseWarning = "File menyerupai ZIP tetapi tidak bisa diparsing sebagai arsip yang valid.";
    }
  } else {
    strings.push(...printableStrings(buffer));
  }
  const joined = strings.join("\n");
  const low = joined.toLowerCase();
  const findings = [];
  for (const [needle, label] of patterns) {
    const count = low.split(needle).length - 1;
    if (count > 0) findings.push({ type: "review", title: label, keyword: needle, count,
      detail: `Ditemukan ${count} kemunculan string terkait “${needle}”. Ini hanya indikator untuk ditinjau, bukan bukti rahasia bocor atau autentikasi bisa dilewati.` });
  }
  const urlMatches = joined.match(/https?:\/\/[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]+/g) || [];
  const urls = [...new Set(urlMatches.map(u => redact(u.replace(/[),;]+$/,"")))].filter(u => u.length < 220)].slice(0, 80);
  const likelyApk = path.extname(filename).toLowerCase() === ".apk";
  const importantFiles = entries.filter(n => /(^|\/)(classes\d*\.dex|AndroidManifest\.xml|resources\.arsc)$/i.test(n)).slice(0, 80);
  return {
    id: crypto.randomUUID(),
    filename: path.basename(filename).slice(0, 160),
    size: buffer.length,
    format: isZip ? (likelyApk ? "APK/ZIP archive" : "ZIP archive") : "Binary/text file",
    entryCount: entries.length,
    importantFiles,
    findings: findings.slice(0, 30),
    urls,
    parseWarning,
    notes: [
      "Pemeriksaan statis berbasis string tidak membuktikan key valid atau autentikasi dapat dilewati.",
      "APK yang dikompresi, obfuscated, terenkripsi, atau berisi binary non-printable mungkin tidak terdeteksi.",
      "Tidak ada file yang dieksekusi dan tidak ada key yang diuji terhadap layanan eksternal.",
      "Validasi trial/key sebaiknya diuji pada server milik Anda menggunakan akun dan key uji."
    ]
  };
}
app.post("/api/analyze", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Pilih file yang didukung (.apk, .dex, .zip, .txt, .xml, .json, .smali)." });
  try {
    const result = analyzeBuffer(req.file.buffer, req.file.originalname || "upload.bin");
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: "File tidak dapat dianalisis." });
  }
});
app.use((err, _req, res, _next) => {
  if (err && err.code === "LIMIT_FILE_SIZE") return res.status(413).json({ error: "Ukuran file maksimal 50 MB." });
  if (err) return res.status(400).json({ error: "Upload gagal. Pastikan jenis file didukung dan ukurannya di bawah 50 MB." });
  res.status(500).json({ error: "Terjadi kesalahan server." });
});
app.listen(PORT, "0.0.0.0", () => console.log(`Xquerpant VIP analyzer listening on port ${PORT}`));
